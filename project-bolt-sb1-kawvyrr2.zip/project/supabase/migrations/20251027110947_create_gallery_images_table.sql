/*
  # Create Gallery Images Table

  1. New Tables
    - `gallery_images`
      - `id` (uuid, primary key) - Unique identifier for each image
      - `user_id` (uuid, foreign key) - References auth.users, owner of the image
      - `image_url` (text) - URL path to the image in Supabase Storage
      - `prompt` (text) - The AI prompt/description associated with the image
      - `created_at` (timestamptz) - When the image was uploaded
      - `updated_at` (timestamptz) - When the image was last updated

  2. Security
    - Enable RLS on `gallery_images` table
    - Policy: Authenticated users can view all images
    - Policy: Users can insert their own images
    - Policy: Users can update their own images
    - Policy: Users can delete their own images

  3. Storage
    - Create a storage bucket named 'gallery-images' for image uploads
    - Enable RLS on the bucket
    - Policy: Authenticated users can upload images
    - Policy: Anyone can view images (public access for display)
    - Policy: Users can delete their own images
*/

-- Create the gallery_images table
CREATE TABLE IF NOT EXISTS gallery_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  image_url text NOT NULL,
  prompt text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;

-- RLS Policies for gallery_images table
CREATE POLICY "Anyone can view all gallery images"
  ON gallery_images FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own images"
  ON gallery_images FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own images"
  ON gallery_images FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own images"
  ON gallery_images FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create storage bucket for gallery images
INSERT INTO storage.buckets (id, name, public)
VALUES ('gallery-images', 'gallery-images', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage bucket
CREATE POLICY "Authenticated users can upload images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'gallery-images');

CREATE POLICY "Anyone can view images"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'gallery-images');

CREATE POLICY "Users can delete their own images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'gallery-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_gallery_images_user_id ON gallery_images(user_id);
CREATE INDEX IF NOT EXISTS idx_gallery_images_created_at ON gallery_images(created_at DESC);