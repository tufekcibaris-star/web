import { useState, useRef } from 'react';
import { X, Upload, Image as ImageIcon } from 'lucide-react';
import { supabase, GalleryImage } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface UploadModalProps {
  onClose: () => void;
  editingImage?: GalleryImage | null;
}

export default function UploadModal({ onClose, editingImage }: UploadModalProps) {
  const [prompt, setPrompt] = useState(editingImage?.prompt || '');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>(editingImage?.image_url || '');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file');
        return;
      }
      setImageFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setError('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!prompt.trim()) {
      setError('Please enter a prompt');
      return;
    }

    if (!editingImage && !imageFile) {
      setError('Please select an image');
      return;
    }

    setUploading(true);
    setError('');

    try {
      let imageUrl = editingImage?.image_url || '';

      if (imageFile) {
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}.${fileExt}`;
        const filePath = `${user?.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('gallery-images')
          .upload(filePath, imageFile);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('gallery-images')
          .getPublicUrl(filePath);

        imageUrl = publicUrl;

        if (editingImage) {
          const oldFileName = editingImage.image_url.split('/').pop();
          if (oldFileName) {
            await supabase.storage
              .from('gallery-images')
              .remove([`${user?.id}/${oldFileName}`]);
          }
        }
      }

      if (editingImage) {
        const { error: updateError } = await supabase
          .from('gallery_images')
          .update({
            prompt,
            image_url: imageUrl,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingImage.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('gallery_images')
          .insert({
            user_id: user?.id,
            image_url: imageUrl,
            prompt,
          });

        if (insertError) throw insertError;
      }

      onClose();
    } catch (err: any) {
      console.error('Error uploading:', err);
      setError(err.message || 'Failed to upload image');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between rounded-t-2xl">
          <h2 className="text-2xl font-bold text-slate-800">
            {editingImage ? 'Edit Image' : 'Upload New Image'}
          </h2>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-700 transition"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Image
            </label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition"
            >
              {previewUrl ? (
                <div className="space-y-3">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="max-h-64 mx-auto rounded-lg"
                  />
                  <p className="text-sm text-slate-600">
                    Click to change image
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <ImageIcon size={48} className="mx-auto text-slate-400" />
                  <div>
                    <p className="text-slate-600 font-medium">
                      Click to upload an image
                    </p>
                    <p className="text-sm text-slate-500 mt-1">
                      PNG, JPG, GIF up to 10MB
                    </p>
                  </div>
                </div>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          <div>
            <label htmlFor="prompt" className="block text-sm font-medium text-slate-700 mb-2">
              Prompt
            </label>
            <textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              required
              rows={8}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none"
              placeholder="Enter the AI prompt or description for this image..."
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-3 px-4 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {uploading ? (
                'Uploading...'
              ) : (
                <>
                  <Upload size={20} />
                  {editingImage ? 'Update' : 'Upload'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
