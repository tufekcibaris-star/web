import { useEffect, useState } from 'react';
import { supabase, GalleryImage } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import FlipCard from './FlipCard';
import UploadModal from './UploadModal';
import { Upload, LogOut } from 'lucide-react';

export default function MasonryGallery() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [editingImage, setEditingImage] = useState<GalleryImage | null>(null);
  const { user, signOut } = useAuth();

  useEffect(() => {
    fetchImages();
  }, []);

  const fetchImages = async () => {
    try {
      const { data, error } = await supabase
        .from('gallery_images')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setImages(data || []);
    } catch (error) {
      console.error('Error fetching images:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const imageToDelete = images.find((img) => img.id === id);
      if (!imageToDelete) return;

      const fileName = imageToDelete.image_url.split('/').pop();
      if (fileName) {
        await supabase.storage
          .from('gallery-images')
          .remove([`${user?.id}/${fileName}`]);
      }

      const { error } = await supabase
        .from('gallery_images')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setImages(images.filter((img) => img.id !== id));
    } catch (error) {
      console.error('Error deleting image:', error);
      alert('Failed to delete image');
    }
  };

  const handleEdit = (image: GalleryImage) => {
    setEditingImage(image);
    setShowUploadModal(true);
  };

  const handleModalClose = () => {
    setShowUploadModal(false);
    setEditingImage(null);
    fetchImages();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600 text-lg">Loading gallery...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-slate-800">Prompt Gallery</h1>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowUploadModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition flex items-center gap-2 font-medium"
            >
              <Upload size={20} />
              Upload
            </button>
            <button
              onClick={signOut}
              className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-2 rounded-lg transition flex items-center gap-2 font-medium"
            >
              <LogOut size={20} />
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {images.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-slate-600 text-lg mb-4">No images yet</p>
            <button
              onClick={() => setShowUploadModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition inline-flex items-center gap-2 font-medium"
            >
              <Upload size={20} />
              Upload Your First Image
            </button>
          </div>
        ) : (
          <div className="masonry-grid">
            {images.map((image) => (
              <FlipCard
                key={image.id}
                image={image}
                isOwner={image.user_id === user?.id}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </main>

      {showUploadModal && (
        <UploadModal
          onClose={handleModalClose}
          editingImage={editingImage}
        />
      )}
    </div>
  );
}
