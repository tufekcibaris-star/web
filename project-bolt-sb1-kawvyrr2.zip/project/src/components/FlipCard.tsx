import { useState } from 'react';
import { Edit2, Trash2, Copy, Eye } from 'lucide-react';
import { GalleryImage } from '../lib/supabase';

interface FlipCardProps {
  image: GalleryImage;
  isOwner: boolean;
  onEdit: (image: GalleryImage) => void;
  onDelete: (id: string) => void;
}

interface PromptModalProps {
  prompt: string;
  onClose: () => void;
}

function PromptModal({ prompt, onClose }: PromptModalProps) {
  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between rounded-t-2xl">
          <h2 className="text-2xl font-bold text-slate-800">Full Prompt</h2>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-700 transition text-2xl w-8 h-8 flex items-center justify-center"
          >
            ✕
          </button>
        </div>
        <div className="p-6">
          <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
            {prompt}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function FlipCard({ image, isOwner, onEdit, onDelete }: FlipCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);
  const [showPromptModal, setShowPromptModal] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const handleCopyImage = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const response = await fetch(image.image_url);
      const blob = await response.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ [blob.type]: blob })
      ]);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy image:', err);
      alert('Failed to copy image to clipboard');
    }
  };

  const handleViewPrompt = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowPromptModal(true);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).replace(/\//g, '.');
  };

  return (
    <>
      <div
        className="flip-card cursor-pointer"
        onClick={() => setIsFlipped(!isFlipped)}
        style={{ breakInside: 'avoid' }}
      >
        <div className={`flip-card-inner ${isFlipped ? 'flipped' : ''}`}>
          <div className="flip-card-front relative">
            <img
              src={image.image_url}
              alt="Gallery item"
              className="w-full h-auto rounded-lg shadow-md object-cover"
              loading="lazy"
            />
            <div className="absolute top-3 right-3 flex gap-2">
              <button
                onClick={handleCopyImage}
                className={`p-2 rounded-lg transition ${
                  copySuccess
                    ? 'bg-green-500 text-white'
                    : 'bg-white/90 hover:bg-white text-slate-700'
                } shadow-lg backdrop-blur-sm`}
                title="Copy image to clipboard"
              >
                <Copy size={18} />
              </button>
              <button
                onClick={handleViewPrompt}
                className="p-2 bg-white/90 hover:bg-white text-slate-700 rounded-lg transition shadow-lg backdrop-blur-sm"
                title="View full prompt"
              >
                <Eye size={18} />
              </button>
            </div>
            <div className="absolute bottom-3 left-3 bg-black/60 text-white px-3 py-1 rounded-lg text-sm backdrop-blur-sm">
              {formatDate(image.created_at)}
            </div>
          </div>

          <div className="flip-card-back">
            <div className="h-full bg-gradient-to-br from-slate-700 to-slate-900 rounded-lg shadow-md p-6 flex flex-col justify-between relative">
              <div className="absolute top-3 right-3 flex gap-2">
                <button
                  onClick={handleCopyImage}
                  className={`p-2 rounded-lg transition ${
                    copySuccess
                      ? 'bg-green-500 text-white'
                      : 'bg-white/20 hover:bg-white/30 text-white'
                  } backdrop-blur-sm`}
                  title="Copy image to clipboard"
                >
                  <Copy size={18} />
                </button>
                <button
                  onClick={handleViewPrompt}
                  className="p-2 bg-white/20 hover:bg-white/30 text-white rounded-lg transition backdrop-blur-sm"
                  title="View full prompt"
                >
                  <Eye size={18} />
                </button>
              </div>
              <div className="overflow-y-auto flex-1 mt-10">
                <h3 className="text-white font-semibold mb-3 text-lg">Prompt</h3>
                <p className="text-slate-200 text-sm leading-relaxed whitespace-pre-wrap">
                  {image.prompt}
                </p>
              </div>
              <div className="text-slate-300 text-xs mt-3 pt-3 border-t border-slate-600">
                {formatDate(image.created_at)}
              </div>

              {isOwner && (
                <div className="flex gap-2 mt-4 pt-4 border-t border-slate-600">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onEdit(image);
                    }}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition flex items-center justify-center gap-2 text-sm font-medium"
                  >
                    <Edit2 size={16} />
                    Edit
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm('Are you sure you want to delete this image?')) {
                        onDelete(image.id);
                      }
                    }}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg transition flex items-center justify-center gap-2 text-sm font-medium"
                  >
                    <Trash2 size={16} />
                    Delete
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {showPromptModal && (
        <PromptModal
          prompt={image.prompt}
          onClose={() => setShowPromptModal(false)}
        />
      )}
    </>
  );
}
